package config;

public class Constants {
	public static final int MAX=100;
}
