package ch03;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// @WebServlet("/ForwardController") 어노테이션 방식 주석처리
public class ForwardController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		// 한글 인코딩 설정
		request.setCharacterEncoding("utf-8");
		String name = request.getParameter("name");
		String color = request.getParameter("color");
		String[] hobby = request.getParameterValues("hobby");
		String message = "";
		switch (color) {
		case "blue": message="자기탐구와 내적 성장을 상징"; break;
		case "green": message="기분의 안정과 온화함을 상징"; break;
		case "red": message="생명을 상징"; break;
		}		
		message += "하는 색입니다.";
		String dept = request.getParameter("dept");
		String email = request.getParameter("email");
		String hp = request.getParameter("hp");
		String[] snack = request.getParameterValues("snack");

		
//		// request객체에 저장
//		request.setAttribute("name", name);
//		request.setAttribute("color", color);
//		request.setAttribute("hobby", hobby);
		
		// HASHMap에 저장
		Map<String,Object> map = new HashMap<>(); // 다형성 기법
		// 맵에 자료 저장
		map.put("name", name);
		map.put("color", color);
		map.put("hobby", hobby);
		map.put("message", message);
		map.put("name", name);
		map.put("dept", dept);
		map.put("email", email);
		map.put("hp", hp);
		map.put("snack", snack);
		
		// request영역에 map을 저장(압축파일이라고 생각하면 됨)
		request.setAttribute("map", map);
		// 포워딩
		RequestDispatcher rd = request.getRequestDispatcher("/ch03/color.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
