package ch01;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/WhileController")
public class WhileController extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		int number=Integer.parseInt(request.getParameter("number"));
		int num=Integer.parseInt(request.getParameter("num"));
		int result=1;
		for(int i=1; i<=num; i++) {
			result *= number;
		}
		System.out.println("결과 : " + result);//톰캣 콘솔창에 출력
		//웹처리
		request.setAttribute("result", result);//Object타입값을 가짐
		RequestDispatcher rd=request.getRequestDispatcher("/ch01/while_result.jsp");
		rd.forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}

