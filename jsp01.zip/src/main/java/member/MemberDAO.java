package member;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import config.DB;

public class MemberDAO {
	public String loginCheck(String userid, String passwd) {
		String name = null; // 리턴할 값(이름)
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null; // select문 처리 결과셋
		try {
			conn = DB.getConn(); // DB연결처리
			String sql = "select name from member where userid=? and passwd=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userid); // 1은 첫번째 물음표를 지정
			pstmt.setString(2, passwd); // 2는 두번째 물음표를 지정
			rs = pstmt.executeQuery();  // select문 전용 실행메소드
			if(rs.next()) { // 레코드가 존재하면(로그인을 성공하면)
				name = rs.getString("name");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			try {
				if(pstmt != null) pstmt.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			try {
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return name;
	}
}
