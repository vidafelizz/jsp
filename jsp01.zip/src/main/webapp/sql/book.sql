create table book (
id number not null,
title varchar2(50),
author varchar2(20),
price number default 0,
qty number default 0,
primary key(id)
);

select nvl(max(id)+1,1) from book;

insert into book values((select nvl(max(id)+1,1) from book), 'OS', 'Willey', 30700, 50);
insert into book values((select nvl(max(id)+1,1) from book), 'Java', 'OReily', 35000, 10);
insert into book values((select nvl(max(id)+1,1) from book), 'C++', '?곸쭊', 45000, 20);
insert into book values((select nvl(max(id)+1,1) from book), 'HTML5', '湲몃쿁', 30000, 15);
insert into book values((select nvl(max(id)+1,1) from book), 'Oracle', '?쒕튆', 40000, 25);

select * from book;

commit;
