CREATE TABLE EMP (  --test_data.sql에서 발췌
  EMPNO     NUMBER(4, 0), 
  ENAME     VARCHAR2(10), 
  JOB       VARCHAR2(9), 
  MGR       NUMBER(4, 0), 
  HIREDATE  DATE, 
  SAL       NUMBER(7, 2),
  COMM      NUMBER(7, 2), 
  DEPTNO    NUMBER(2, 0)
);
insert into emp values (7369,'김철수','사원',7902,'2000-12-17',200,null,20);
insert into emp values (7499,'이찬수','주임',7698,'2001-02-20',260,300,30);
insert into emp values (7521,'박종수','주임',7698,'2002-02-22',325,500,30);
insert into emp values (7566,'임채호','과장',7839,'2001-04-02',497,null,20);

select * from emp;
desc emp; --컬럼 구조 보기

--테이블 복사(레코드는 복사되지 않음), 1=0은 false를 의미
create table emp2 as select * from emp where 1=0;

alter table emp2 modify empno number(10);
alter table emp2 modify ename varchar2(20);
alter table emp2 modify deptno number(10);
commit;

select count(*) from emp2; ----트랜잭션 처리 완료 후 확인
