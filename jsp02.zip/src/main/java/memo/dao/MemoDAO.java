package memo.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import memo.dto.MemoDTO;
import sqlmap.MybatisManager;

public class MemoDAO {
	
	//mybatis에서는 시스템상 ArrayList가 아닌 List를 쓰도록 고정시켜 놨다.
	public List<MemoDTO> listMemo(String searchkey, String search){
		SqlSession session=MybatisManager.getInstance().openSession();
		List<MemoDTO> list=null;
		try {
			if(searchkey.equals("writer_memo")) {//이름+메모로 검색
				list=session.selectList("memo.listAll", search);//selectList("네임스페이스.아이디")
			}else {//메모로만, 이름으로만 검색
				Map<String,String> map=new HashMap<>();
				map.put("searchkey", searchkey);
				map.put("search", search);
				list=session.selectList("memo.list", map);
			}
			// insert때보다 특수문자처리 등은 select때 처리가 좋다.
			for(MemoDTO dto : list) {
				String memo = dto.getMemo();
				memo = memo.replace("  ", "&nbsp;&nbsp;"); // 공백문자처리(스페이스 2개만 처리해도 알아서 해석)
				memo = memo.replace("<", "&lt;"); // Less Than ~보다 작다
				memo = memo.replace(">", "&gt;"); // Greater Than ~보다 크다
				// 키워드에 색상 처리(색 처리 등은 가급적 특수문자처리 끝부분에 해야 태그 무력화 영향을 안 받는다.)
				if(searchkey.equals("memo")) {
					if(memo.indexOf(search) != -1) {
						memo = memo.replace(search, "<font color='red'>" + search + "</font>");
					}
				}
				dto.setMemo(memo);
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(session != null) session.close();//mybatis 객체 닫기
		}
		
		return list;
	}

	public void insertMemo(MemoDTO dto) {
		//mybatis 실행 객체 생성
		SqlSession session=MybatisManager.getInstance().openSession();
		// 태그 문자 처리
//		String memo = dto.getMemo();
//		memo = memo.replace("  ", "&nbsp;&nbsp;"); // 공백문자처리(스페이스 2개만 처리해도 알아서 해석)
//		memo = memo.replace("<", "&lt;"); // Less Than ~보다 작다
//		memo = memo.replace(">", "&gt;"); // Greater Than ~보다 크다
//		dto.setMemo(memo);
		
		
		session.insert("memo.insert", dto);
		//mybatis에서는 파라미터가 1개 밖에는 전달이 안된다.
		session.commit();//수동커밋, mybatis는 자동커밋을 막았다.
		session.close();//mybatis 세션 닫기
	}
	
	// 수정,삭제를 위한 상세페이지
	public MemoDTO viewMemo(int idx) {
		SqlSession session=MybatisManager.getInstance().openSession();
		MemoDTO dto = session.selectOne("memo.view", idx);
		// selectList() : 레코드가 2개 이상 가져올때(목록을 가져올때)
		// selectOne() : 레코드가 1개만 가져올때
		session.close();
		return dto;
	}
	
	// 메모수정
	public void updateMemo(MemoDTO dto) {
		SqlSession session=MybatisManager.getInstance().openSession();
		session.update("memo.update", dto); // 네임스페이스.아이디
		session.commit(); // DB에 변화가 있을때(insert, update, delete)는 반드시 커밋 처리, mybatis는 자동커밋을 막아둠
		session.close();
	}

	public void deleteMemo(int idx) {
		SqlSession session=MybatisManager.getInstance().openSession();
		session.delete("memo.delete", idx);
		session.commit();
		session.close();
	}
}
