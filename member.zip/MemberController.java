package member;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/member_servlet/*")
public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		// 사용자가 요청한 주소
		String uri = request.getRequestURI();
		// 컨텍스트 패스(웹프로젝트의 식별자, 이름)
		String context = request.getContextPath();
		MemberDAO dao = new MemberDAO();
		
		// list.do
		if(uri.indexOf("list.do") != -1) {
//			System.out.println("list.do호출...");
//			System.out.println(request.getRequestURI());
//			System.out.println(uri.indexOf("list.do"));
		
			Map<String,Object> map = new HashMap<>();
			List<MemberDTO> list = dao.memberList();
			map.put("list", list); // 맵에 자료 저장
			map.put("count", list.size()); // 레코드의 개수(회원수)
			// 웹영역(request)에 저장
			request.setAttribute("map", map);
			// 포워딩
			String page = "/ch06/member_list.jsp";
			RequestDispatcher rd = request.getRequestDispatcher(page);
			rd.forward(request, response);
		} else if(uri.indexOf("join.do") != -1) {
			String userid = request.getParameter("userid");
			String passwd = request.getParameter("passwd");
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			String hp = request.getParameter("hp");
			String zipcode = request.getParameter("zipcode");
			String address1 = request.getParameter("address1");
			String address2 = request.getParameter("address2");
			
			MemberDTO dto = new MemberDTO();
			dto.setUserid(userid); // dto의 setter를 통한 자료저장
			dto.setPasswd(passwd);
			dto.setName(name);
			dto.setEmail(email);
			dto.setHp(hp);
			dto.setZipcode(zipcode);
			dto.setAddress1(address1);
			dto.setAddress2(address2);
			dao.insert(dto);
		} else if(uri.indexOf("view.do") != -1) {
			String userid = request.getParameter("userid");
			System.out.println("클릭한 아이디 : " + userid);
			MemberDTO dto = dao.memberDetail(userid);
			// 웹영역에 저장(request 영역)
			request.setAttribute("dto", dto);
			String page = "/ch06/member_view.jsp";
			// 포워딩
			RequestDispatcher rd = request.getRequestDispatcher(page);
			rd.forward(request, response);
		} else if(uri.indexOf("update.do") != -1) {
			String userid = request.getParameter("userid");
			String passwd = request.getParameter("passwd");
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			String hp = request.getParameter("hp");
			String zipcode = request.getParameter("zipcode");
			String address1 = request.getParameter("address1");
			String address2 = request.getParameter("address2");
			
			MemberDTO dto = new MemberDTO();
			dto.setUserid(userid); // dto의 setter를 통한 자료저장
			dto.setPasswd(passwd);
			dto.setName(name);
			dto.setEmail(email);
			dto.setHp(hp);
			dto.setZipcode(zipcode);
			dto.setAddress1(address1);
			dto.setAddress2(address2);
			// 레코드 수정 처리
			dao.update(dto); // 서블릿에서 메소드 만들기
			// 페이지 이동(리다이렉트 처리)
			response.sendRedirect(context + "/ch06/member.jsp");
		} else if(uri.indexOf("delete.do") != -1) {
			String userid = request.getParameter("userid");
			// 레코드 삭제 처리
			dao.delete(userid);
			// 페이지 이동
			response.sendRedirect(context+"/ch06/member.jsp");		
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
